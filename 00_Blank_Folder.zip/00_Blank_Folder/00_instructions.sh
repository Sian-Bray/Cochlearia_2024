# Change directory so that you are in this folder
	# cd /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/02_Visualisation_Folder/00_Blank_Folder

# Run Find_BPM_outliers.py
	# you will need your Scantools bpm output file

	# Example commands:

		# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/EU_dips_Vs_tets_15_BPM_ws1000.txt -c 12 -t Top -p 1 -o temp_files/temp1.txt
		# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/UK_dips_Vs_tets_15_BPM_ws1000.txt -c 12 -t Top -p 1 -o temp_files/temp1.txt

		# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/EU_dips_Vs_tets_15_BPM_ws5000.txt -c 12 -t Top -p 1 -o temp_files/temp1.txt
		# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/UK_dips_Vs_tets_15_BPM_ws5000.txt -c 12 -t Top -p 1 -o temp_files/temp1.txt

		# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/EU_dips_Vs_tets_15_BPM_ws1000.txt -c 10 -t Top -p 1 -o temp_files/temp1.txt
		# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/UK_dips_Vs_tets_15_BPM_ws1000.txt -c 10 -t Top -p 1 -o temp_files/temp1.txt

	# -c could be 6-13 in these examples (outname	scaff	start	end	win_size	num_sites	num_snps	Rho	FstWC	dxy	AFD	FixedDiff	FstH	FstN)

# Run BPM_to_outlier_dot_plots.py

	# You will need to modify line 74 to have the correct number of alleles! i.e. "tetraploids 96 diploids 16" for 8 diploids and 24 tetraploids.

	# Make sure you have the files:

		# genes_only.gtf - a gtf file containing only genes e.g. line: "33	AUGUSTUS	gene	1	2616	0.32	+	.	ID=g1"
			# e.g. generation command: grep 'gene' C_excelsa_V5_braker2_wRseq.gff3 | grep 'AUGUSTUS' > genes_only.gtf
				# (then remove the ';' manually)

		# R.gene_window_plot.py
			# You will need to modify line 74 to have the correct number of alleles

		# Allele frequency .table files, one per scaffold
			# e.g. generation:
				# Make a table file for each VCF
					# See tables_to_visualise.sh for examples
				# Paste together in Unix
					# paste british_tets.table british_dips.table > British_dips_and_tets.table
				# Manually fix headder
					# i.e. extra tab where the headders fuse and at the end of the headder
				# Split by scaffold
					# python3 /Users/sian_bray/Dropbox/Scripts/split_table_file.py British_dips_and_tets.table

			# gene_orientation_file.txt
				# e.g. line  "g1	scaffold_33	1	2616	+"
				# see '/Users/sian_bray/Dropbox/Scripts/gene_orientation_file_from_genes_only.py'

	# Example commands:

		# python3 BPM_to_outlier_dot_plots.py -n UK_dips_Vs_tets_15_ws1000_BPM_FstH -p 1
		# python3 BPM_to_outlier_dot_plots.py -n EU_dips_Vs_tets_15_ws1000_BPM_FstH -p 1

		# python3 BPM_to_outlier_dot_plots.py -n UK_dips_Vs_tets_15_ws5000_BPM_FstH -p 1
		# python3 BPM_to_outlier_dot_plots.py -n EU_dips_Vs_tets_15_ws5000_BPM_FstH -p 1

		# python3 BPM_to_outlier_dot_plots.py -n UK_dips_Vs_tets_15_ws1000_BPM_AFD -p 1
		# python3 BPM_to_outlier_dot_plots.py -n EU_dips_Vs_tets_15_ws1000_BPM_AFD -p 1

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ #

# Example full runs:

	# cd /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/02_Visualisation_Folder/01_UK_Dips_Tets
	# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/UK_dips_Vs_tets_15_BPM.txt -c 12 -t Top -p 1 -o temp_files/temp1.txt
	# python3 BPM_to_outlier_dot_plots.py -n UK_dips_Vs_tets_15_BPM_FstH -p 1

	# cd /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/02_Visualisation_Folder/02_EU_Dips_Tets
	# python3 Find_BPM_outliers.py -i /Users/sian_bray/Dropbox/Bray/000_Research/Cochlearia_Massive/01_Data/EU_dips_Vs_tets_15_BPM.txt -c 12 -t Top -p 1 -o temp_files/temp1.txt
	# python3 BPM_to_outlier_dot_plots.py -n EU_dips_Vs_tets_15_BPM_FstH -p 1




